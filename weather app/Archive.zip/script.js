
const icon = document.querySelector(".icon_img")
const temp = document.querySelector(".temp")
const desc = document.querySelector(".desc")
const f_like = document.querySelector(".f_like")

const form = document.querySelector("form");
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const value = form.querySelector("input").value;
  handleWeatherData(value);
});

const sendRequest = (url) => {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();

    request.addEventListener("readystatechange", () => {
      if (request.readyState === 4 && request.status === 200) {
        resolve(JSON.parse(request.responseText));
      }
      if (request.readyState === 4 && request.status !== 200) {
        reject("Failed to Fetch");
      }
    });

    request.open("GET", url);
    request.send();
  });
};

const getBgImage = async () => {
  const url =
    "https://api.unsplash.com/photos/random?client_id=oqTv9lB2pj4Am-ZXN9ORNmE_i_bKip8QhfgzoxRV-AQ";
  try {
    const data = await sendRequest(url);
    const imgURL = data.urls.raw;
    document.body.style = `background: linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)),url(${imgURL});background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  min-height: 100vh;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center`;
  } catch (err) {
    console.log(err);
  }
};

getBgImage();



const handleWeatherData = async(city)=>{
   const url =
    `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=3ed1a8944ae36bde087adc8f67d0f04a&units=metric`

    try {
    const data = await sendRequest(url);
    const temperature = data.main.temp
    const description= data.weather[0].description
    const feels_like= data.main.feels_like
    const iconUrl = ` https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`

    temp.textContent =      `Temperature : ${temperature}`
    desc.textContent =      `Description : ${description}`
    f_like.textContent =      `Feels Like : ${feels_like}`
    icon.setAttribute("src" , iconUrl)

    document.querySelector("#details").classList.remove("hidden")

  } catch (err) {
    console.log(err);
  } 
}